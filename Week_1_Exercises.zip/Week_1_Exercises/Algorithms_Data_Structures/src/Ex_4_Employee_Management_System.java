//  5005723_Abu_Samar


/*
Array Representation in Memory:
Contiguous Block: Arrays are stored in a contiguous block of memory. This means all elements are placed next to each other, starting from a base address.
Index-Based Access: You can access any element in an array in constant time O(1) using its index, as the position of each element is directly calculable.

Advantages:
Fast Access: Direct indexing provides quick retrieval and modification of elements.
Memory Efficiency: Since arrays use contiguous memory, they can be more memory-efficient compared to data structures that require additional pointers or references.
 */




class Employee {
    private String employeeId;
    private String name;
    private String position;
    private double salary;

    // Constructor
    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters
    public String getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary=" + salary + "]";
    }
}
class EmployeeManager {
    private Employee[] employees;
    private int size;

    // Constructor
    public EmployeeManager(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    // Search for an employee by ID
    public Employee searchEmployeeById(String employeeId) {
        for (Employee emp : employees) {
            if (emp != null && emp.getEmployeeId().equals(employeeId)) {
                return emp;
            }
        }
        return null;
    }

    // Traverse and display all employees
    public void traverseEmployees() {
        for (Employee emp : employees) {
            if (emp != null) {
                System.out.println(emp);
            }
        }
    }

    // Delete an employee by ID
    public boolean deleteEmployeeById(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                // Shift elements to the left
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return true;
            }
        }
        return false;
    }
}
public class Ex_4_Employee_Management_System{
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager(5);

        // Adding employees
        manager.addEmployee(new Employee("E001", "Abu", "Developer", 75000));
        manager.addEmployee(new Employee("E002", "Samar", "Designer", 65000));
        manager.addEmployee(new Employee("E003", "Aamir", "Manager", 85000));

        // Traversing employees
        System.out.println("All Employees:");
        manager.traverseEmployees();

        // Searching for an employee
        System.out.println("\nSearching for employee with ID E002:");
        Employee employee = manager.searchEmployeeById("E002");
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        System.out.println("\nDeleting employee with ID E002:");
        boolean deleted = manager.deleteEmployeeById("E002");
        if (deleted) {
            System.out.println("Employee deleted.");
        } else {
            System.out.println("Employee not found.");
        }

        // Traversing employees after deletion
        System.out.println("\nAll Employees after deletion:");
        manager.traverseEmployees();
    }
}


/*
Time Complexity of Operations:

Add:
Best and Average Case: O(1)
Adding an employee to the next available slot in the array is constant time, provided there is space.
Worst Case: O(n)
If the array is full and needs resizing, this would involve creating a new array and copying existing elements.

Search:
Best Case: O(1)
If the employee is found at the first position.
Average Case: O(n)
On average, you may need to check half of the array elements.
Worst Case: O(n)
If the employee is at the end of the array or not found.

Traverse:
Time Complexity: O(n)
You need to visit each element in the array once.

Delete:
Best Case: O(1)
If the employee to be deleted is at the end of the array.
Average and Worst Case: O(n)
You need to search for the employee (O(n)) and then shift elements (O(n)).

Limitations of Arrays:
Fixed Size: Once created, the size of an array cannot be changed. This can be limiting if the number of employees changes frequently.
Inefficient Deletion: Deleting an element requires shifting all subsequent elements, which can be inefficient.
Insertion Complexity: Inserting an element in the middle of the array is also inefficient because of the need to shift elements.

When to Use Arrays:
Small and Static Data Sets: Arrays work well when the number of records is relatively small and doesn’t change often.
Simple Data Management: Arrays are suitable for scenarios where the simplicity of implementation is more important than dynamic size or frequent insertions/deletions. For larger or more dynamic datasets, consider using more flexible data structures like lists or dynamic arrays.
 */