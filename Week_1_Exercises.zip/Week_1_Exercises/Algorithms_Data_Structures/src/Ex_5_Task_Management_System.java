//  5005723_Abu_Samar


/*
Types of Linked Lists:

Singly Linked List:
Structure: Each node contains data and a reference (or link) to the next node in the list.
Traversal: Only forward traversal is possible, from the head to the end.
Insertion/Deletion: Can be efficient if you have a reference to the node before the insertion/deletion point.

Doubly Linked List:
Structure: Each node contains data and two references: one to the next node and one to the previous node.
Traversal: Can traverse in both directions (forward and backward), which is useful for operations that require bidirectional access.
Insertion/Deletion: More flexible than singly linked lists because you can easily access both adjacent nodes.
 */





//Ex_5_Task_Management_System
class Task {
    private String taskId;
    private String taskName;
    private String status;

    // Constructor
    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Task [taskId=" + taskId + ", taskName=" + taskName + ", status=" + status + "]";
    }
}
class Node {
    Task task;
    Node next;

    // Constructor
    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

class TaskLinkedList {
    private Node head;

    // Add a task to the linked list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by ID
    public Task searchTaskById(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse and display all tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by ID
    public boolean deleteTaskById(String taskId) {
        Node current = head;
        Node previous = null;

        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                if (previous == null) {
                    head = current.next; // Deleting the head node
                } else {
                    previous.next = current.next;
                }
                return true;
            }
            previous = current;
            current = current.next;
        }
        return false;
    }
}
public class Ex_5_Task_Management_System{
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        // Adding tasks
        taskList.addTask(new Task("T001", "Design Database", "In Progress"));
        taskList.addTask(new Task("T002", "Develop API", "Pending"));
        taskList.addTask(new Task("T003", "Test Application", "Completed"));

        // Traversing tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Searching for a task
        System.out.println("\nSearching for task with ID T002:");
        Task task = taskList.searchTaskById("T002");
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a task
        System.out.println("\nDeleting task with ID T002:");
        boolean deleted = taskList.deleteTaskById("T002");
        if (deleted) {
            System.out.println("Task deleted.");
        } else {
            System.out.println("Task not found.");
        }

        // Traversing tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        taskList.traverseTasks();
    }
}


/*
Add:
Best and Average Case: O(n)
Adding a task involves traversing to the end of the list. The time complexity is linear due to the traversal.

Search:
Best Case: O(1)
If the task is the first node.
Average Case: O(n)
On average, you might need to check half of the list.
Worst Case: O(n)
If the task is at the end or not found.

Traverse:
Time Complexity: O(n)
You must visit each node once, which requires linear time.

Delete:
Best Case: O(1)
If the task is the head node.
Average Case: O(n)
Requires traversing to find the task and adjusting pointers.
Worst Case: O(n)
If the task is at the end or not found.

Advantages of Linked Lists Over Arrays:

Dynamic Size: Linked lists can easily grow and shrink in size as needed, unlike arrays which have a fixed size.
Efficient Insertions/Deletions: Adding or removing elements is efficient (O(1)) if you have a reference to the node, especially compared to shifting elements in an array.
Flexible Memory Usage: Linked lists use memory for elements and pointers, which can be more flexible for dynamic data compared to arrays, which require contiguous memory.
*/
