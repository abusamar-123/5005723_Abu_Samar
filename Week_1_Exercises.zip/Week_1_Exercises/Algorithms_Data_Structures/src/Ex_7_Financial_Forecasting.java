//  5005723_Abu_Samar


/*
Recursion occurs when a function calls itself directly or indirectly to solve a problem.
Recursion can simplify complex problems by breaking them down into smaller, more manageable sub-problems that are easier to solve.
 */



public class Ex_7_Financial_Forecasting
{

    public static double calculateFutureValue(double initialValue, double growthRate, int years) 
    {   
        if (years == 0) 
        {
            return initialValue;
        }
        return calculateFutureValue(initialValue * (1 + growthRate), growthRate, years - 1);
    }
    public static void main(String[] args) 
    {
        double initialValue = 1000.0;  
        double growthRate = 0.05;      
        int years = 10;                
        double futureValue = calculateFutureValue(initialValue, growthRate, years);
        System.out.println("Future Value: $" + futureValue);
    }
}


/*
Time Complexity: O(n)
Each recursive call reduces the number of periods by one until it reaches the base case.
 Thus, the total number of recursive calls is proportional to the number of periods.

Optimizing Recursive Solutions:
Memoization:Store previously computed results to avoid redundant calculations.
 */