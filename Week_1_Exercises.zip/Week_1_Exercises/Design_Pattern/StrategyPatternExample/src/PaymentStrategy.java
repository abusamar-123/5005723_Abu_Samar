//  5005723_Abu_Samar



public interface PaymentStrategy {
    void pay(double amount);
}
