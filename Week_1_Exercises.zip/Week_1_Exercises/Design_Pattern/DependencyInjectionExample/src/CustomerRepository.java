//  5005723_Abu_Samar



public interface CustomerRepository {
    String findCustomerById(int id);
}
