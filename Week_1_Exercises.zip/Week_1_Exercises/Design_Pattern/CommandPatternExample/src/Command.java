//  5005723_Abu_Samar


public interface Command {
    void execute();
}
