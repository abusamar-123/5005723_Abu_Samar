//  5005723_Abu_Samar



public interface Observer {
    void update(double stockPrice);
}
