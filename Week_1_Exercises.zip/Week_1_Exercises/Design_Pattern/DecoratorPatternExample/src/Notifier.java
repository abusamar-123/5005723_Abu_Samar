//  5005723_Abu_Samar


public interface Notifier {
    void send(String message);
}
