//  5005723_Abu_Samar


public interface PaymentProcessor {
    void processPayment(double amount);
}
